using System;

namespace $safeprojectname$.Models
{
    public class City
    {
       public string CityName { get; set; }
       public Double Latitude { get; set; }
       public Double Longtitude { get; set; }


    }
}
