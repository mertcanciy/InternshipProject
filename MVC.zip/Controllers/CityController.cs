using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using $safeprojectname$.Models;

namespace $safeprojectname$.Controllers
{
    public class CityController : Controller
    {
        private readonly ILogger<CityController> _logger;

        public CityController(ILogger<CityController> logger)
        {
            _logger = logger;
        }

        public IActionResult CitiesOnMap()
        {
            List<City> cities = new List<City>();

           cities.Add(new City { CityName = "Hatay", Latitude = 36.401848, Longtitude = 36.349812 });
           cities.Add(new City { CityName = "Konya", Latitude = 37.874641, Longtitude = 32.493156 });
           cities.Add(new City { CityName = "Istanbul", Latitude = 41.008240, Longtitude = 28.978359 });
           cities.Add(new City { CityName = "Izmir", Latitude = 38.423733, Longtitude = 27.142826 });
           cities.Add(new City { CityName = "Samsun", Latitude = 41.279701, Longtitude = 36.336067 });
           cities.Add(new City { CityName = "Antalya", Latitude = 36.896893, Longtitude = 30.713324 });
           cities.Add(new City { CityName = "Bursa", Latitude = 40.188526, Longtitude = 29.060965 });
           cities.Add(new City { CityName = "Manisa", Latitude = 38.614033, Longtitude = 27.429562 });
           cities.Add(new City { CityName = "Mersin", Latitude = 36.812103, Longtitude = 34.641479 });
           cities.Add(new City { CityName = "Ankara", Latitude = 39.933365, Longtitude = 32.859741 });

           TempData["cities"] = Newtonsoft.Json.JsonConvert.SerializeObject(cities);
           TempData.Keep("cities");
           return View(); 
        }

       
        [HttpPost]
        public IActionResult CitiesOnMap(string SelectedCity)
        {
            if (TempData["cities"] != null)
            {
                foreach (var redirectedCity in Newtonsoft.Json.JsonConvert.DeserializeObject<List<City>>(TempData["cities"] as string))
                {                    
                    if (String.Equals(redirectedCity.CityName, SelectedCity))
                    {

                        TempData["selectedCity"] = Newtonsoft.Json.JsonConvert.SerializeObject(redirectedCity); ;
                        return RedirectToAction(redirectedCity.CityName, "City");
                    }
                }
            }
            return RedirectToAction(SelectedCity, "City"); ;
        }


        public IActionResult Hatay()
        {
            return View();
        }
        public IActionResult Ankara()
        {
            return View();
        }
        public IActionResult Antalya()
        {
            return View();
        }
        public IActionResult Bursa()
        {
            return View();
        }
        public IActionResult Istanbul()
        {
            return View();
        }
        public IActionResult Izmir()
        {
            return View();
        }
        public IActionResult Konya()
        {
            return View();
        }
        public IActionResult Manisa()
        {
            return View();
        }
        public IActionResult Mersin()
        {
            return View();
        }
        public IActionResult Samsun()
        {
            return View();
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
